function verify(){
const exp = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/

let input = prompt("Unesite svoj e-mail da vas možemo kontaktirati");

if (input.match(exp)){
    alert("Hvala!");
    return true
}
else{
    alert("Unos nije ispravan! Molimo, unesite ponovno.");
    return false
}
}

